#ifndef PICTURE__INC
#define PICTURE__INC
#pragma once
#include <fstream>

class PictureEntity ;

class Picture
{
public:
	Picture(void);
	Picture(const char* const *, int);
	Picture(const Picture&);
	~Picture(void);

	Picture& operator=(const Picture&);
	Picture reframe(int p, char c);
	Picture reframe(char c, char v, char h);
	Picture split(int id);
	Picture clone(void) const;

	friend std::ostream& operator<<(std::ostream&, const Picture&);
	friend Picture enframe(const Picture&, char c ='+', char v ='-', char h ='|');
	friend Picture operator&(const Picture&, const Picture&);
	friend Picture operator|(const Picture&, const Picture&);

	friend class BasicPicture;
	friend class FramedPicture;
	friend class VcatPicture;
	friend class HcatPicture;
private:
	PictureEntity *ap ;
	Picture(PictureEntity* p);

	int width(void) const;
	int height(void) const;
	std::ostream& display(std::ostream&, int, int) const;
};

Picture enframe(const Picture& pic ,char c,char v,char h);

#endif
