#include "picture.h"
#include "pictureEntity.h"

Picture::Picture(void):ap(0) {}

Picture::Picture(const char * const *pic, int n) :ap(new BasicPicture(pic, n)) {}

Picture::Picture(const Picture &pic):ap(pic.ap) { if(ap) ap->incuse();}

Picture::~Picture(void){ if(ap && ap->decuse()==0) delete ap;}

Picture& Picture::operator=(const Picture &pic)
{
	if(pic.ap) pic.ap->incuse();
	if(ap && ap->decuse()==0) delete ap;
	ap = pic.ap;
	return *this;
}

Picture::Picture(PictureEntity* p):ap(p) { if(ap) p->incuse();}

int Picture::width(void) const { return ap->width();}
int Picture::height(void) const { return ap->height();}

ostream& Picture::display(ostream& o, int y, int mw) const { return ap->display(o, y, mw);}

Picture Picture::reframe(int p, char c) { return ap ? ap->reframe(p, c): Picture();}

Picture Picture::reframe(char c, char v, char h){ return ap ? ap->reframe(c, v, h): Picture();}

Picture Picture::split(int id) { return ap ? ap->split(id) : Picture();}

Picture Picture::clone(void) const { return ap ? ap->clone() : Picture();}

ostream& operator<<(ostream& o, const Picture& pic)
{
	int ht = pic.height();
	for(int i=0; i<ht; i++)
	{
		pic.display(o, i, 0);
		o<< std::endl;
	}
	return o;
}
