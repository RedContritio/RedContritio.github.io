#include "pictureEntity.h"
#include <cstring>

PictureEntity::PictureEntity(void):use(1) {}

PictureEntity::~PictureEntity(void) {}

ostream& PictureEntity::fillEmpty(ostream& o, int start, int mw, char _ch) const
{
	for(int i=start ;i<mw ;i++ ) o <<_ch;
	return o;
}

int PictureEntity::max(int a, int b) { return a>b?a:b;}

Picture PictureEntity::reframe(int p, char c) { return Picture();}
Picture PictureEntity::reframe(char c, char v, char h) { return Picture();}

#pragma warning(push)
#pragma warning(disable:4996)
BasicPicture::BasicPicture(const char * const *_Content, int _Lines)
	: m_data(new char* [_Lines]), m_size(_Lines), m_maxwidth(0 ), m_width(new int[_Lines])
{
	for(int i=0; i<_Lines; ++i)
	{
		m_width[i] =strlen(_Content[i]);
		m_data[i] = new char[m_width[i]+1];
		if(m_maxwidth < m_width[i]) m_maxwidth = m_width[i];
		strcpy(m_data[i], _Content[i]);
	}
}
#pragma warning(pop)

BasicPicture::~BasicPicture(void)
{
	for(int i=0 ;i<m_size ;i++ )
	{
		delete [] m_data[i];
	}
	delete []m_data ;
}

void BasicPicture::incuse(void){++use ;}
int BasicPicture::decuse(void ){return --use ;}

int BasicPicture::width(void) const{ return m_maxwidth;}
int BasicPicture::height(void) const{ return m_size;}
ostream& BasicPicture::display(ostream& o, int y, int mw)const 
{
	if(y<0 || y>=m_size) return fillEmpty(o, 0, mw);
	else
	{
		o<< m_data[y];
		return fillEmpty(o, m_width[y], mw);
	}
}

Picture BasicPicture::split(int id) { return this;}
Picture BasicPicture::clone(void)
{
	return new BasicPicture(m_data, m_size);
}

FramedPicture::FramedPicture(const Picture& pic, char c, char v, char h) : 
	m_insidePic(pic), c1(c), c2(c), c3(c), c4(c), t(v), b(v), l(h), r(h) {}
FramedPicture::FramedPicture(const Picture& pic, char ct, char cb, char v, char h) :
	m_insidePic(pic), c1(ct), c2(ct), c3(cb), c4(cb), t(v), b(v), l(h), r(h) {}
FramedPicture::FramedPicture(const Picture& pic, char ct, char cb, char _t, char _b, char _l, char _r) :
	m_insidePic(pic), c1(ct), c2(ct), c3(cb), c4(cb), t(_t), b(_b), l(_l), r(_r) {}
FramedPicture::FramedPicture(const Picture& pic, char _c1, char _c2, char _c3, char _c4,
							 char _t, char _b, char _l, char _r) :
	m_insidePic(pic), c1(_c1), c2(_c2), c3(_c3), c4(_c4), t(_t), b(_b), l(_l), r(_r) {}

FramedPicture::~FramedPicture(void) {}

void FramedPicture::incuse(void) { ++use;}
int FramedPicture::decuse(void ) { return --use;}

Picture FramedPicture::reframe(int pos, char c)
{
	switch(pos){
		case 0: c1 = c; break;		case 1: t = c; break;		case 2: c2 = c; break;
		case 3: l = c; break;		default: break;				case 5: r = c; break;
		case 6: c3 = c; break;		case 7: b = c; break;		case 8: c4 = c; break;
	}
	return this;
}

Picture FramedPicture::reframe(char corner, char v, char h)
{
	c1 = c2 = c3 = c4 = corner;
	t = b = v;
	l = r = h;
	return this;
}

int FramedPicture::width(void) const {return (m_insidePic.width())+2;}
int FramedPicture::height(void) const {return (m_insidePic.height())+2;}

ostream& FramedPicture::display(ostream& o, int y, int mw) const 
{
	if(y<0 || y>=height())
	{
		return fillEmpty(o, 0, mw);
	}
	else
	{
		if(y == 0)
			return fillEmpty(o << c1, 0, m_insidePic.width(), t) << c2;
		else if(y+1 == height())
			return fillEmpty(o << c3, 0, m_insidePic.width(), b) << c4;
		else
			return m_insidePic.display(o<<l, y-1, m_insidePic.width()) << r;
	}
}

Picture FramedPicture::split(int id) { return m_insidePic;}

Picture FramedPicture::clone(void)
{
	return new FramedPicture(m_insidePic.clone(), c1, c2, c3, c4, t, b, l, r);
}

Picture enframe(const Picture& pic ,char c,char v,char h){
	return Picture(new FramedPicture(pic, c, v, h));
}

VcatPicture::VcatPicture(const Picture &up, const Picture &down):top(up),bottom(down) {}

VcatPicture::~VcatPicture(void) {}

void VcatPicture::incuse(void) { ++use;}
int VcatPicture::decuse(void) { return --use;}

int VcatPicture::width(void) const { return max(top.width(), bottom.width());}
int VcatPicture::height(void ) const { return top.height()+bottom.height();}

ostream& VcatPicture::display(ostream& o, int y, int mw) const
{
	if(y>=0 && y<top.height())
		return top.display(o, y, mw);
	else if(y>=top.height() && y<height())
		return bottom.display(o, y-top.height(), mw);
	else
		return fillEmpty(o, 0, mw);
}
Picture VcatPicture::split(int id) { return id&1? bottom: top;}
Picture VcatPicture::clone(void)
{
	return new VcatPicture(top.clone(), bottom.clone());
}

Picture operator&(const Picture& up, const Picture& down)
{
	return new VcatPicture(up, down);
}

HcatPicture::HcatPicture(const Picture &l , const Picture &r ) : left(l),right(r) {}

HcatPicture::~HcatPicture(void) {}

void HcatPicture::incuse(void){ ++use;}
int HcatPicture::decuse(void ){ return --use;}

int HcatPicture::width(void) const { return left.width()+right.width();}
int HcatPicture::height(void) const { return max(left.height(), right.height());}

ostream& HcatPicture::display(ostream &o, int y, int mw) const
{
	left.display(o, y, left.width());
	right.display(o, y, right.width());
	return fillEmpty(o, left.width()+right.width(), mw);
}

Picture HcatPicture::split(int id) { return id&1? right: left;}

Picture HcatPicture::clone(void)
{
	return new HcatPicture(left.clone(), right.clone());
}

Picture operator|(const Picture& l, const Picture& r)
{
	return new HcatPicture(l, r);
}
