#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>

#include "picture.h"

using std::cout ;

const char* pic[] ={"Glad" ,"to be here" ,"and so on" };

int main()
{
	Picture x(pic, 3);
	Picture y = enframe(x) ;
	Picture z = enframe(x|y);
	y.reframe('*', '_', '8');
	cout<< (z&y)<<std::endl;
	Picture a = y.clone();
	a.reframe('.', '-', '|').reframe(6, '\'').reframe(8, '\'');
	cout<< (a|y) <<std::endl;
	return 0 ;
}
