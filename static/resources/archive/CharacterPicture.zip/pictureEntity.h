#ifndef PICTUREENTITY__INC
#define PICTUREENTITY__INC
#pragma once

#include "picture.h"
using std::ostream;

class PictureEntity
{
public:
	PictureEntity(void);
	virtual ~PictureEntity(void) = 0;
	virtual void incuse(void) = 0;
	virtual int decuse(void) = 0;
	friend class Picture;
protected:
	int use;
	virtual int width(void) const = 0;
	virtual int height(void) const = 0;
	virtual ostream& display(ostream&, int, int) const = 0;
	ostream& fillEmpty(ostream&, int, int, char _ch = ' ') const;
	static int max(int a, int b);
	virtual Picture reframe(int pos, char c);
	virtual Picture reframe(char c, char v, char h);
	virtual Picture split(int id) = 0;
	virtual Picture clone(void) = 0;
};

class BasicPicture : public PictureEntity
{
public:
	BasicPicture(const char* const*, int);
	~BasicPicture(void);
	void incuse(void);
	int decuse(void);

	int width(void) const;
	int height(void) const;
	ostream& display(ostream&, int, int)const;
	
	Picture split(int id);
	
	Picture clone(void);
private:
	char **m_data;
	int m_size;
	int *m_width;
	int m_maxwidth;
};

class FramedPicture : public PictureEntity
{
public:
	FramedPicture(const Picture&, char c, char v, char h);
	FramedPicture(const Picture&, char ct, char cb, char v, char h);
	FramedPicture(const Picture&, char ct, char cb, char t, char b, char l, char r);
	FramedPicture(const Picture&, char c1, char c2, char c3, char c4, char t, char b, char l, char r);
	~FramedPicture(void);
	void incuse(void);
	int decuse(void);
	
	Picture reframe(int pos, char c);
	Picture reframe(char corner, char v, char h);

	int width(void) const;
	int height(void) const;
	ostream& display(ostream&, int y, int mw) const;
	
	Picture split(int id);
	Picture clone(void);

	friend Picture enframe(const Picture&);
private:
	Picture m_insidePic;
	char c1, c2, c3, c4;
	char l, r, t, b;
};

class VcatPicture : public PictureEntity
{
public:
	VcatPicture(const Picture&, const Picture&);
	~VcatPicture(void);
	void incuse(void);
	int decuse(void);
	
	int width(void)const ;
	int height(void)const ;
	ostream& display(ostream&, int y, int mw) const;
	Picture split(int id);
	Picture clone(void);

	friend Picture operator&(const Picture&, const Picture&);
private:
	Picture top, bottom;
};

class HcatPicture :public PictureEntity
{
public:
	HcatPicture(const Picture&, const Picture&);
	~HcatPicture(void);
	void incuse(void);
	int decuse(void);
	
	int width(void)const ;
	int height(void)const ;
	ostream& display(ostream&, int y, int mw) const;
	Picture split(int id);
	Picture clone(void);

	friend Picture operator|(const Picture&, const Picture&);
private:
	Picture left, right;
};
#endif
